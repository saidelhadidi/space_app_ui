import 'package:flutter/material.dart';
import 'package:space_app_ui/my_app.dart';

void main() {
  runApp(MyApp());
}
